﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace KRV.LawnPro.Mobile.Custom
{
    public class MyDatePicker: DatePicker
    {
    }
}
