﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KRV.LawnPro.Web
{
    public class AppSettings
    {
        public string ApiBaseUri { get; set; }

        public Color ThemeColor { get; set; }
    }
}
